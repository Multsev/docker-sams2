# sams2db DUMP FOR MySQL DATABASE
TRUNCATE TABLE auth_param;
INSERT INTO auth_param VALUES('ntlm','enabled','0');
INSERT INTO auth_param VALUES('ldap','enabled','0');
INSERT INTO auth_param VALUES('adld','enabled','0');
INSERT INTO auth_param VALUES('ncsa','enabled','0');
INSERT INTO auth_param VALUES('ip','enabled','1');
INSERT INTO auth_param VALUES('ldap','ldapserver','127.0.0.1');
INSERT INTO auth_param VALUES('ldap','basedn','dc=example,dc=com');
INSERT INTO auth_param VALUES('ldap','adadmin','cn=Manager,dc=example,dc=com');
INSERT INTO auth_param VALUES('ldap','adadminpasswd','secret');
INSERT INTO auth_param VALUES('ldap','usersrdn','ou=People');
INSERT INTO auth_param VALUES('ldap','usersfilter','(objectClass=Person)');
INSERT INTO auth_param VALUES('ldap','usernameattr','gecos');
INSERT INTO auth_param VALUES('ldap','groupsrdn','ou=Group');
INSERT INTO auth_param VALUES('ldap','groupsfilter','(objectClass=posixGroup)');
TRUNCATE TABLE passwd;
INSERT INTO passwd VALUES('admin','00YfpO1MXDzqQ','2','2','0');
INSERT INTO passwd VALUES('auditor','00MTbxknCTtNs','1','0','');
TRUNCATE TABLE proxy;
INSERT INTO proxy VALUES('1','Proxy server','301392','http://127.0.0.1/sams2/icon/classic/blank.gif','http://127.0.0.1/sams2/messages','sams','1','ip','/usr/bin','','0','2','2','5','1','1','1','0','real','1','9','workgroup','1','','','1024','1048576','0.0.0.0','workgroup','Administrator','0','Users','1','2','2');
TRUNCATE TABLE redirect;
INSERT INTO redirect VALUES('1','allow','allow','');
INSERT INTO redirect VALUES('2','Локальная сеть','local','');
INSERT INTO redirect VALUES('3','deny','denied','');
TRUNCATE TABLE sconfig;
INSERT INTO sconfig VALUES('2','1');
INSERT INTO sconfig VALUES('2','3');
TRUNCATE TABLE sconfig_time;
INSERT INTO sconfig_time VALUES('1','1');
INSERT INTO sconfig_time VALUES('2','1');
INSERT INTO sconfig_time VALUES('3','1');
INSERT INTO sconfig_time VALUES('4','1');
TRUNCATE TABLE sgroup;
INSERT INTO sgroup VALUES('1','Administrators');
INSERT INTO sgroup VALUES('2','Users');
TRUNCATE TABLE shablon;
INSERT INTO shablon VALUES('1','Default','ip','0','D','1980-01-01','1','-1');
INSERT INTO shablon VALUES('2','Users','ip','100','D','1980-01-01','0','-1');
INSERT INTO shablon VALUES('3','Admin','ip','0','D','1980-01-01','0','-1');
TRUNCATE TABLE squiduser;
TRUNCATE TABLE sysinfo;
INSERT INTO sysinfo VALUES('1','1','File System Usage','1.0.0-a','Andrey Ovcharov','<table width=100% class=sysplugtable>
  <th>Filesystem</th>
  <th>Size</th>
  <th>Used</th>
  <th>Avail</th>
  <th>Use%</th>
  <th>Mounted on</th>
<tr>  <td>overlay</td>
  <td align="center">251 G</td>
  <td align="center">29 G</td>
  <td align="center">210 G</td>
  <td align="center">13%</td>
  <td>/</td>
</tr><tr>  <td>tmpfs</td>
  <td align="center">64 M</td>
  <td align="center">0</td>
  <td align="center">64 M</td>
  <td align="center">0%</td>
  <td>/dev</td>
</tr><tr>  <td>tmpfs</td>
  <td align="center">3.1 G</td>
  <td align="center">0</td>
  <td align="center">3.1 G</td>
  <td align="center">0%</td>
  <td>/sys/fs/cgroup</td>
</tr><tr>  <td>shm</td>
  <td align="center">64 M</td>
  <td align="center">12 K</td>
  <td align="center">64 M</td>
  <td align="center">1%</td>
  <td>/dev/shm</td>
</tr><tr>  <td>/dev/sdc</td>
  <td align="center">251 G</td>
  <td align="center">29 G</td>
  <td align="center">210 G</td>
  <td align="center">13%</td>
  <td>/etc/resolv.conf</td>
</tr><tr>  <td>/dev/sdc</td>
  <t','2021-08-21 11:38:01','1');
INSERT INTO sysinfo VALUES('2','1','Load average','1.0.0-a','Andrey Ovcharov','<table width=100% class=sysplugtable>
<th width=30%>Uptime</th>
<th width=30%>Logged in Users</th>
<th width=40%>Load average</th>
<tr>
  <td align="center"> 0:18</td>
  <td align="center">0</td>
  <td align="center">0.00, 0.01, 0.03</td>
</tr>
</table>
','2021-08-21 11:38:01','1');
TRUNCATE TABLE timerange;
INSERT INTO timerange VALUES('1','Full day','MTWHFAS','00:00:00','23:59:59');
TRUNCATE TABLE url;
INSERT INTO url VALUES('2','2','10.0.0.0/8');
INSERT INTO url VALUES('4','2','172.16.0.0/12');
INSERT INTO url VALUES('5','2','192.168.0.0/16');
INSERT INTO url VALUES('6','2','fc00::/7');
INSERT INTO url VALUES('7','2','fe80::/10');
TRUNCATE TABLE websettings;
INSERT INTO websettings VALUES('UTF8','classic','1','1','1','nick','1','fpdf','2.0.0');
